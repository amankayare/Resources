const { Router } = require('express');
const multer = require('multer');
const { z } = require('zod');
const validate = require('../middlewares/validate.middleware');
const config = require('../../config');

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: config.MAX_UPLOAD_SIZE_MB * 1024 * 1024 },
});

// ----- Validation Schemas -----

const uploadJsonSchema = z.object({
  provider: z.string().min(1),
  filename: z.string().min(1),
  mimeType: z.string().min(1),
  file: z.string().min(1), // Base64
});

const confirmSchema = z.object({
  provider: z.string().min(1),
});

const stageJsonSchema = z.object({
  filename: z.string().min(1),
  mimeType: z.string().min(1),
  file: z.string().min(1),
});

/**
 * Creates and returns the assets router.
 * @param {import('../controllers/assets.controller')} controller
 */
function createAssetsRouter(controller) {
  const router = Router();

  // Upload — supports both multipart and JSON/Base64
  router.post(
    '/upload',
    upload.single('file'),
    (req, res, next) => {
      // Skip body validation when a file was uploaded via multipart
      if (req.file) return next();
      return validate(uploadJsonSchema)(req, res, next);
    },
    controller.upload
  );

  // Get URL
  router.get('/:assetId/url', controller.getUrl);

  // Delete
  router.delete('/:assetId', controller.delete);

  // Stage
  router.post(
    '/stage',
    upload.single('file'),
    (req, res, next) => {
      if (req.file) return next();
      return validate(stageJsonSchema)(req, res, next);
    },
    controller.stage
  );

  // Confirm staged
  router.post('/stage/:stageId/confirm', validate(confirmSchema), controller.confirmStaged);

  // Discard staged
  router.delete('/stage/:stageId', controller.discardStaged);

  return router;
}

module.exports = createAssetsRouter;
